<?php
include 'config.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if (isset($_POST['dp'])) {
    $datepkdata = $_POST['dp'];
    $getictr = $_POST['getictr'];
    $checkeditable = 1;
    $todaysdate = date('Y m');
    $todaysdatearray = explode(" ", $todaysdate);
    $todaysyear = $todaysdatearray[0];
    $todaysmonth = $todaysdatearray[1];
    list($stdatepk, $sttimepk, $stfpk) = explode(" ", $datepkdata);
//echo $stdate; // start select date 
    list($stmonthpk, $stdaypk, $styearpk) = explode("/", $stdatepk);
    $nstdatepk = $styearpk . "-" . $stmonthpk . "-" . $stdaypk;
    echo '<h2>
    <span class="label label-default">Date Showing : ' . $nstdatepk . '</span>
     </h2>';
    $originalDate = $styearpk . '-' . $stmonthpk . '-' . $stdaypk;

    $date = date("M j, Y", strtotime($originalDate));
//    $date = "Mar 27, 2011";
    $date = strtotime($date);
    
    if($todaysyear > $styearpk){
        $checkeditable = 0;
    }
    else{
            if($todaysmonth > $stmonthpk){ $checkeditable = 0; }
            else{ $checkeditable = 1; }
        }
        
    
    $tasks_array = array();
    $i = 0; // remembers number of tasks in task table
    $x = 1; // for serialising form input id's
    $ti = 0; // remembers timesheet_is for start date
    $mondaytotal = 0;
    $tuesdaytotal = 0;
    $wednesdaytotal = 0;
    $thursdaytotal = 0;
    $fridaytotal = 0;
    $saturdaytotal = 0;
    $sundaytotal = 0;
    $daystotal = 0;
    $coursetotal = 0;
    $weekstotal = 0;
    $sqlti = "SELECT * FROM instructor_timesheet WHERE start_date = '$nstdatepk'";
    $resti = mysqli_query($connect, $sqlti);

    if ($resti->num_rows >= 1) { //mysqli
        while ($rowti = $resti->fetch_array(MYSQLI_BOTH)) { //mysqli
            $ti = $rowti['timesheet_id'];
            $comment_st = $rowti['comment'];
        }
    }
    $sqltasks = "SELECT * FROM instructor_tasks";
    $restasks = mysqli_query($connect, $sqltasks);

    if ($restasks->num_rows >= 1) { //mysqli
        while ($rowtasks = $restasks->fetch_array(MYSQLI_BOTH)) { //mysqli
            $tasks_id = $rowtasks['instask_id'];
            $tasks_array[$i] = $rowtasks;
            $i++;
        }
    }
    echo "<br />";
    ?>
    <form id="taskform" class="form-signin" method="post" action="home.php" role="form" >
        <?php
        echo '
          <input type="hidden" name="dateselected" value="' . $nstdatepk . '"/>
    <table class="table table-bordered table-striped ">
    <thead>
      <tr>
        <th>Task</th>
        <th>Monday</th>
        <th>Tuesday</th>
        <th>Wednesday</th>
        <th>Thursday</th>
        <th>Friday</th>
        <th>Saturday</th>
        <th>Sunday</th>
        <th><i>Total</i></th>
      </tr>
    </thead>
    <tbody>';

        for ($a = 0; $a < $i; $a++) {
            $task_id_now = $tasks_array[$a][0];
            $task_name_now = $tasks_array[$a][1];
            $sqltaskpk = "SELECT * FROM instructor_weeks iw , instructor_tasks it , instructor_timesheet itm "
                    . "WHERE it.instask_id = '$task_id_now'"
                    . "AND iw.timesheet_id = '$ti'"
                    . "AND iw.ictr_id = '$getictr'"
                    . "AND iw.instask_id = it.instask_id";
            $restaskpk = mysqli_query($connect, $sqltaskpk);
            if ($restaskpk->num_rows >= 1) { //mysqli
                while ($rowtaskpk = $restaskpk->fetch_array(MYSQLI_BOTH)) { //mysqli
                    $weeks_id = $rowtaskpk['weeks_id'];
                    $instask_id = $rowtaskpk['instask_id'];
                    $instask_name = $rowtaskpk['task'];
                    $timesheet_id = $rowtaskpk['timesheet_id'];
                    $monday = $rowtaskpk['monday'];
                    $tuesday = $rowtaskpk['tuesday'];
                    $wednesday = $rowtaskpk['wednesday'];
                    $thursday = $rowtaskpk['thursday'];
                    $friday = $rowtaskpk['friday'];
                    $saturday = $rowtaskpk['saturday'];
                    $sunday = $rowtaskpk['sunday'];
                    $coursetotal = $monday + $tuesday + $wednesday + $thursday + $friday + $saturday + $sunday;
                }
                if($checkeditable === 0){
                echo'
      <tr>
        <td><input type="hidden" name="taskid' . $x . '" class="form-control" value="' . $task_id_now . '" readonly/>'
                . '<input type="text" name="taskname' . $x . '" class="form-control" value="' . $instask_name . '" readonly/></td>
        <td><input type="number" step=0.01 name="monday' . $x . '" min="0" max="10" class="form-control" value="' . $monday . '" readonly/></td>
        <td><input type="number" step=0.01 name="tuesday' . $x . '" min="0" max="10" class="form-control" value="' . $tuesday . '" readonly/></td>
        <td><input type="number" step=0.01 name="wednesday' . $x . '" min="0" max="10" class="form-control" value="' . $wednesday . '" readonly/></td>
        <td><input type="number" step=0.01 name="thursday' . $x . '" min="0" max="10" class="form-control" value="' . $thursday . '" readonly/></td>
        <td><input type="number" step=0.01 name="friday' . $x . '" min="0" max="10" class="form-control" value="' . $friday . '" readonly/></td>
        <td><input type="number" step=0.01 name="saturday' . $x . '" min="0" max="10" class="form-control" value="' . $saturday . '" readonly/></td>
        <td><input type="number" step=0.01 name="sunday' . $x . '" min="0" max="10" class="form-control" value="' . $sunday . '" readonly/></td>
            <td><i>' . $coursetotal . '</i></td>
      </tr>';
              }
              else if($checkeditable === 1){
                               echo'
      <tr>
        <td><input type="hidden" name="taskid' . $x . '" class="form-control" value="' . $task_id_now . '" readonly/>'
                . '<input type="text" name="taskname' . $x . '" class="form-control" value="' . $instask_name . '" readonly/></td>
        <td><input type="number" step=0.01 name="monday' . $x . '" min="0" max="10" class="form-control" value="' . $monday . '"/></td>
        <td><input type="number" step=0.01 name="tuesday' . $x . '" min="0" max="10" class="form-control" value="' . $tuesday . '"/></td>
        <td><input type="number" step=0.01 name="wednesday' . $x . '" min="0" max="10" class="form-control" value="' . $wednesday . '"/></td>
        <td><input type="number" step=0.01 name="thursday' . $x . '" min="0" max="10" class="form-control" value="' . $thursday . '"/></td>
        <td><input type="number" step=0.01 name="friday' . $x . '" min="0" max="10" class="form-control" value="' . $friday . '"/></td>
        <td><input type="number" step=0.01 name="saturday' . $x . '" min="0" max="10" class="form-control" value="' . $saturday . '"/></td>
        <td><input type="number" step=0.01 name="sunday' . $x . '" min="0" max="10" class="form-control" value="' . $sunday . '"/></td>
            <td><i>' . $coursetotal . '</i></td>
      </tr>';
              }
                
                $mondaytotal = $mondaytotal + $monday;
                $tuesdaytotal = $tuesdaytotal + $tuesday;
                $wednesdaytotal = $wednesdaytotal + $wednesday;
                $thursdaytotal = $thursdaytotal + $thursday;
                $fridaytotal = $fridaytotal + $friday;
                $saturdaytotal = $saturdaytotal + $saturday;
                $sundaytotal = $sundaytotal + $sunday;
                $weekstotal = $mondaytotal + $tuesdaytotal + $wednesdaytotal + $thursdaytotal + $fridaytotal + $saturdaytotal + $sundaytotal;
            } else {
                if($checkeditable === 0){
                echo'
      <tr>
        <td><input type="hidden" name="taskid' . $x . '" class="form-control" value="' . $task_id_now . '" readonly/>'
                . '<input type="text" name="taskname' . $x . '" class="form-control" value="' . $task_name_now . '" readonly/></td>
        <td><input type="number" step=0.01 name="monday' . $x . '" min="0" max="10" class="form-control" value="" readonly/></td>
        <td><input type="number" step=0.01 name="tuesday' . $x . '" min="0" max="10" class="form-control" value="" readonly/></td>
        <td><input type="number" step=0.01 name="wednesday' . $x . '" min="0" max="10" class="form-control" value="" readonly/></td>
        <td><input type="number" step=0.01 name="thursday' . $x . '" min="0" max="10" class="form-control" value="" readonly/></td>
        <td><input type="number" step=0.01 name="friday' . $x . '" min="0" max="10" class="form-control" value="" readonly/></td>
        <td><input type="number" step=0.01 name="saturday' . $x . '" min="0" max="10" class="form-control" value="" readonly/></td>
        <td><input type="number" step=0.01 name="sunday' . $x . '" min="0" max="10" class="form-control" value="" readonly/></td>
            <td><i>' . $coursetotal . '</i></td>
      </tr>';
                }
              else if($checkeditable === 1){
                               echo'
      <tr>
        <td><input type="hidden" name="taskid' . $x . '" class="form-control" value="' . $task_id_now . '" readonly/>'
                . '<input type="text" name="taskname' . $x . '" class="form-control" value="' . $task_name_now . '" readonly/></td>
        <td><input type="number" step=0.01 name="monday' . $x . '" min="0" max="10" class="form-control" value=""/></td>
        <td><input type="number" step=0.01 name="tuesday' . $x . '" min="0" max="10" class="form-control" value=""/></td>
        <td><input type="number" step=0.01 name="wednesday' . $x . '" min="0" max="10" class="form-control" value=""/></td>
        <td><input type="number" step=0.01 name="thursday' . $x . '" min="0" max="10" class="form-control" value=""/></td>
        <td><input type="number" step=0.01 name="friday' . $x . '" min="0" max="10" class="form-control" value=""/></td>
        <td><input type="number" step=0.01 name="saturday' . $x . '" min="0" max="10" class="form-control" value=""/></td>
        <td><input type="number" step=0.01 name="sunday' . $x . '" min="0" max="10" class="form-control" value=""/></td>
            <td><i>' . $coursetotal . '</i></td>
      </tr>';
              }
            }
            $x++;
        }
        echo'
      <tr>
        <td>Day\'s Total</td>
        <td><i>' . $mondaytotal . '</i></td>
        <td><i>' . $tuesdaytotal . '</i></td>
        <td><i>' . $wednesdaytotal . '</i></td>
        <td><i>' . $thursdaytotal . '</i></td>
        <td><i>' . $fridaytotal . '</i></td>
        <td><i>' . $saturdaytotal . '</i></td>
        <td><i>' . $sundaytotal . '</i></td>
        <td><b>' . $weekstotal . '</b></td>
      </tr>';
        echo '
    </tbody>
  </table>
  <input type="hidden" name="rows" value="' . $x . '" class="form-control" value=""/>
    <div class="row"><div class="col-sm-2"><h4>COMMENT:</h4></div>
        <div class="col-sm-10"><textarea class="form-control" name="comment">' . $comment_st . '</textarea>
        </div>
   </div>
   <br />
   <div class="row"><div class="col-sm-offset-10 col-sm-2">
  <button name="tasksave" id="tasksave" class="form-control btn btn-info btn-block" value="tasksave" type="submit">Save <span class="glyphicon glyphicon-floppy-disk" ></span> </button>
  </div></div>
  ';
        ?>
    </form> 
    <?php
}
if (isset($_POST['deltask_id'])) {
    $taskid = $_POST['deltask_id'];
    $taskname = $_POST['deltask_name'];
    $sqldelweek = "DELETE FROM instructor_weeks WHERE instask_id = '$taskid'";
    $resdelweek = mysqli_query($connect, $sqldelweek) OR DIE(mysqli_error());
    if ($resdelweek) {
        $sqldeltask = "DELETE FROM instructor_tasks WHERE instask_id = '$taskid'";
        $resdeltask = mysqli_query($connect, $sqldeltask) OR DIE(mysqli_error());
    }
}
if (isset($_POST['edittask_id'])) {
    $taskid = $_POST['edittask_id'];
    $taskname = $_POST['edittask_name'];

// $sqldeltask = "DELETE FROM instructor_tasks WHERE instask_id = '$taskid'"; 
// $resdeltask = mysqli_query($connect,$sqldeltask) OR DIE(mysqli_error());
}

// Insert attendance in database 
if(isset($_POST['std_bid']) && isset($_POST['std_id']) && isset($_POST['rdo'])){
    $sid= $_POST['std_id'] ;
    $bid = $_POST['std_bid'];
    $dt = $_POST['t_date'];
    $att = $_POST['rdo'];
    $sql_att = "SELECT * FROM student_attendance WHERE batch_id='$bid'"
            . "AND student_id = '$sid'"
            . "AND date ='$dt'";
    $res_att= mysqli_query($connect, $sql_att) or die(mysqli_errno());
    $count = mysqli_num_rows($res_att);
   while($row = $res_att->fetch_array(MYSQLI_BOTH)){ 
       $att_p = $row['st_attendance_id'];
   }
    if($count == '1'){
        $sql_att_u =  "UPDATE student_attendance SET attendance_ind = '$att' WHERE st_attendance_id = '$att_p'"; //mysqli
        $res_att_u= mysqli_query($connect,$sql_att_u) OR die(mysqli_error());
        if($res_att_u){
        echo 3;
        }else{
             echo die(mysqli_error());
        }
    }else{
        $sql = "INSERT INTO student_attendance(student_id,batch_id,date,attendance_ind) VALUES('$sid','$bid','$dt','$att')"; //mysqli
        $res = mysqli_query($connect,$sql) OR die (mysqli_error());
        if($res){
            echo 1;
        }else{
             echo die(mysqli_error());
        }
    }
     
}
// Challenge Score Page
if(isset($_POST['bch_id_s_list_ch'])){
    $stud_bch_id = $_POST['bch_id_s_list_ch'];
    $sql_student = "SELECT * FROM student_batch b, student s WHERE batch_id='$stud_bch_id'"
            . "AND b.student_id = s.student_id";
    $res_student= mysqli_query($connect, $sql_student);
    $count = mysqli_num_rows($res_student);
    if($count == '0'){
       echo "<h2>No Record Found !</h2>"; 
    }else{ ?>
        <table class="table table-bordered table-striped"  style="margin-bottom: 10%;width: 70%;margin-left: 15%;">
            <thead>
                <tr style="font-size:large;">
                    <th>Student id</th><th>Name</th><th>Score</th>
                </tr>
            </thead>
            <tbody> <?php 
            while($row = $res_student->fetch_array(MYSQLI_BOTH)){ 
                
                echo "<tr><td>".$row['student_id']."</td>"
                        . "<td>".$row['first_name']." ".$row['last_name']."</td>"
                        . "<td><a href='#' class='btn btn-black'>Enter Score</td>"
                    . "</tr>";
                echo "";
            } ?>
            </tbody>
        </table>
     <?php
    }
}
// Course id to get Course Level
if(isset($_POST['sec_cid'])){
    $s_cid = $_POST['sec_cid'];
    $sql_cl =  "SELECT * FROM course_level WHERE course_id='$s_cid'"; //mysqli
    $res_cl = mysqli_query($connect,$sql_cl) OR die(mysqli_error());
    while($row = $res_cl->fetch_array(MYSQLI_BOTH)){
        $clid = $row['course_level_id'];
        $cl_nam = $row['level_name'];
//        echo $clid.$cl_nam;
        echo "<option value='$clid'>$cl_nam</option>";
    }
} 
// check challenge number 
if(isset($_POST['check_cl']) && isset($_POST['check_ch_num'])){
    $ch_cl = $_POST['check_cl'];
    $ch_num = $_POST['check_ch_num'];
    $sql_chk =  "SELECT * FROM challenges WHERE course_level_id='$ch_cl'"
            . "AND challenge_nbr='$ch_num'"; //mysqli
    $res_chk = mysqli_query($connect,$sql_chk) OR die(mysqli_error());
    $count = mysqli_num_rows($res_chk);
    if($count == '0'){
       echo 1;
    }  else{
        echo 0;
    }
}
// Insert Challenge details 
if(isset($_POST['scl_cr_cl'])){
    $cr_cl = $_POST['scl_cr_cl'];
    $ch_num = $_POST['ch_number'];
    $ch_scor = $_POST['ch_score'] ;
    $ch_des = $_POST['ch_desc'];
    $ch_type = $_POST['ch_type'];
    $ch_cat = $_POST['ch_cat'];
    $sql_cd = "INSERT INTO challenges(course_level_id,challenge_nbr,challenge_desc,challenge_type,challenge_score,challenge_category) "
            . "VALUES('$cr_cl','$ch_num','$ch_des','$ch_type','$ch_scor','$ch_cat')"; //mysqli
    $res_cd = mysqli_query($connect,$sql_cd) OR die (mysqli_error());
    if($res_cd){
        echo 1;
    }else{
        echo die(mysqli_error());
    }
}
// Insert Challenge Score
if(isset($_POST['ch_tot'])){
    $tot = $_POST['ch_tot'];
    $ch_sid = $_POST['ch_sid'];
    $ch_dt = $_POST['t_date'];
    for($i=1;$i <= $tot; $i++){
       $ch_id=$_POST['ch_id'.$i];
       $ch_chk=$_POST['ch_chk'.$i];
       $ch_sr = $_POST['ch_sr'.$i];
//       echo $ch_chk;
       if($ch_chk == '1'){
//           echo $ch_id."-".$ch_chk;
            $sql_ch_id = "INSERT INTO student_class_score(student_id,challenge_id,rec_ent_dt) "
            . "VALUES('$ch_sid','$ch_id','$ch_dt')"; //mysqli
            $res_ch_id = mysqli_query($connect,$sql_ch_id) OR die (mysqli_error());
       }else if($ch_chk == ''){
            $sql_ch_up =  "DELETE FROM student_class_score WHERE st_sore_id = '$ch_sr'"; //mysqli
            $res_ch_up = mysqli_query($connect,$sql_ch_up) OR die(mysqli_error($connect));
       }
       else{
           
       }
    }
    echo 1;
}
?> 