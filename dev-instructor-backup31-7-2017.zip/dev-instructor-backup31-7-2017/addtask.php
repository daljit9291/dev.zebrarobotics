<?php
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
session_start();
include 'config.php';
include 'function_in.php';
$sqltasklist = "SELECT * FROM instructor_tasks";
$restasklist = mysqli_query($connect,$sqltasklist) OR die(mysql_error());
?>
<!DOCTYPE html>
<html>
    <head><?php head_lib();
        nav_style();?>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.3/js/bootstrap-datetimepicker.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.3/css/bootstrap-datetimepicker.min.css">
    </head>
    <?php
if (!empty($_SESSION['t_id'])) {
    $ictr_id = $_SESSION['t_id'];
     if (isset($_POST["edittask"])) {
         $oldtaskid = $_POST["oldtaskid"];
         $oldtaskname = $_POST["oldtaskname"];
         $newtaskname = $_POST["newtaskname"];
         $newtaskname = strtoupper($newtaskname);
                         $sqlchecktask =  "SELECT * FROM instructor_tasks WHERE task = '$newtaskname'"; //mysqli
                        $reschecktask= mysqli_query($connect,$sqlchecktask) OR die(mysqli_error());
                        if ($reschecktask->num_rows >= 1) {
                            function alert($msg) {
                               echo "<script type='text/javascript'>alert('$msg');"
                                       . "window.location.href = 'addtask.php'</script>";
                           }
                           alert("Course Already Exist!!");
                        }
                        else{
                        $sql =  "UPDATE instructor_tasks SET task = '$newtaskname' WHERE instask_id = '$oldtaskid'"; //mysqli
                        $res= mysqli_query($connect,$sql) OR die(mysqli_error());
                        if ($res) {
                   //         header("Location: addtask.php");
                            function alert($msg) {
                               echo "<script type='text/javascript'>alert('$msg');"
                                       . "window.location.href = 'addtask.php'</script>";
                           }
                           alert("Updated Successfully!!");
                        }
                        }
     }
 if (isset($_POST["add"])) {
     $new_task = $_POST["new_task"];
     $new_task = strtoupper($new_task);
     $sqlchecktask =  "SELECT * FROM instructor_tasks WHERE task = '$new_task'"; //mysqli
     $reschecktask= mysqli_query($connect,$sqlchecktask) OR die(mysqli_error());
     if ($reschecktask->num_rows >= 1) {
         function alert($msg) {
            echo "<script type='text/javascript'>alert('$msg');"
                    . "window.location.href = 'addtask.php'</script>";
        }
        alert("Course Already Exist!!");
     }
     else{
     $sql =  "INSERT INTO instructor_tasks(task) VALUES ('$new_task')"; //mysqli
     $res= mysqli_query($connect,$sql) OR die(mysqli_error());
     if ($res) {
//         header("Location: addtask.php");
         function alert($msg) {
            echo "<script type='text/javascript'>alert('$msg');"
                    . "window.location.href = 'addtask.php'</script>";
        }
        alert("Course Inserted Successfully!!");
//        swal('Good job!', 'You clicked the button!', 'success');
     }
     }
 }       
 else{?>
    <body><?php navbar_i();?>
        <div class="container">
                <div class="row">
            <div class="col-md-8 col-md-offset-2">
                
                <div class="box"><div class="title">Tasks Available</div>
                    <div class="body">
                        <div id='modal'>
                            <!-- Modal -->
<div class="modal fade" id="editTaskModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Edit Task</h4>
      </div>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
      <div class="modal-body">
          <table><thead><tr>
                      <th></th>
                      <th>Old Task Name</th>
                      <th>New Task Name</th>
                  </tr></thead>
              <tbody>
          <div class="row">
              <th><input id='oldtaskid' name='oldtaskid' type="hidden" class="form-control col-sm-2" value="" readonly /></th>
              <th><input id="oldtaskname" name="oldtaskname" class="form-control col-sm-5" type="text" value="" readonly /></th>
              <th><input id="newtaskname" name="newtaskname" class="form-control col-sm-5" type="text" /></th>
          </div>
              </tbody></table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" name="edittask" class="btn btn-primary">Save changes</button>
      </div>
        </form>
    </div>
  </div>
</div>
                       </div>
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>Task</th>
                                </tr>
                            </thead>
                            <tbody>
                        <?php if ($restasklist->num_rows >= 1) {
                            $i = 1;
                                    while($rowtasklist = $restasklist->fetch_array(MYSQLI_BOTH)){ //mysqli
                                    echo '';
                                        $instask_id = $rowtasklist['instask_id'];
                                        $task = $rowtasklist['task'];
                                        echo '<div class="row "><tr>'
                                        . '<input type="hidden" value="'.$instask_id.'" class="form-control col-sm-2" readonly />'
                                                . '<th><input type="text" value="'.$i.'" class="form-control col-sm-2" readonly /></th>'
                                                . '<th><input id="taskname" type="text" value="'.$task.'" class="form-control col-sm-5" readonly/></th>';
//                                        echo '<th><a class="form-control btn btn-danger btn-block d_in col-sm-3 deltask" data-taskdid=' . $rowtasklist['instask_id'] . ' data-taskdname=' . $rowtasklist['task'] . '  style="margin-top: -7px;" >Delete</a></th>'
//                                                . '<th><a class="form-control btn btn-info btn-block d_in col-sm-3 edittask" data-toggle="modal" data-target="#editTaskModal" data-taskedid=' . $rowtasklist['instask_id'] . ' data-taskedname=' . $rowtasklist['task'] . ' style="margin-top: -7px;" disabled>Update</a></th>';
                                    echo '</tr>';
                                        
                                   $i++; }
                                }
                                $i = 1;
                        ?>
                                </tbody>
                        </table>
                        <form method="POST" id ="dailyreport" action="<?php $_SERVER['PHP_SELF'];?>" class="form-horizontal" role="form">

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-12" style="text-align: center;" >Add New Task:</div>
                                </div><hr/>
                                <div class="row">
                                <label class="control-label col-sm-3" >Task Name:</label>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control" id="new_task" name="new_task" required/>
                                    </div>
                                <div class="col-sm-2">
                                    <button type="submit" class="btn btn-primary btn-block active" name="add" >
                                        Add Task
                                    </button>
                                </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>    
            </div>
            </div>
        <!--/// row end-->
    </div>
    </body>
</html><?php
}
 } else{
	header('Location: index.php');
}