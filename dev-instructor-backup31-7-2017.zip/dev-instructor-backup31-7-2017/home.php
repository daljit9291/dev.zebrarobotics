<?php
session_start();
include 'config.php';
include 'function_in.php';
if (!empty($_SESSION['t_id'])) {
    $ictr_id = $_SESSION['t_id'];
 if (isset($_POST["tasksave"])) {
     $dateselected = $_POST["dateselected"];
     $comment = $_POST["comment"];
     $taskrows = $_POST["rows"];
     $monday="-";$tuesday="-";$wednesday="-";$thursday="-";$friday="-";$saturday="-";$sunday="-";
     $sqlstart = "SELECT timesheet_id FROM instructor_timesheet WHERE start_date = '$dateselected'";
     $resstart = mysqli_query($connect, $sqlstart) OR DIE(mysqli_error());
         if($resstart->num_rows >= 1){ //mysqli
            while($rowstart = $resstart->fetch_array(MYSQLI_BOTH)){ //mysqli
                $timesheet_id=$rowstart['timesheet_id'];
                   for($a=1;$a<$taskrows;$a++){
                        $task_id = $_POST["taskid$a"];
                        $task_name = $_POST["taskname$a"];
                        $monday = $_POST["monday$a"];
                        $tuesday = $_POST["tuesday$a"];
                        $wednesday = $_POST["wednesday$a"];
                        $thursday = $_POST["thursday$a"];
                        $friday = $_POST["friday$a"];
                        $saturday = $_POST["saturday$a"];
                        $sunday = $_POST["sunday$a"];
                        $sqlweeks_id = "SELECT weeks_id FROM instructor_weeks iw , instructor_timesheet itm , instructor_tasks itk WHERE iw.ictr_id = '$ictr_id' AND itm.start_date = '$dateselected' AND itk.instask_id = '$task_id' AND iw.timesheet_id = itm.timesheet_id AND iw.instask_id = itk.instask_id";
                        $resweeks_id = mysqli_query($connect, $sqlweeks_id) OR DIE(mysqli_error());
                            if($resweeks_id->num_rows >= 1){ //mysqli
                                while($rowweeks_id = $resweeks_id->fetch_array(MYSQLI_BOTH)){ //mysqli
                                    $weeks_id = $rowweeks_id['weeks_id'];
                                    $sqlupweeks = "UPDATE instructor_weeks SET monday = '$monday',tuesday = '$tuesday',wednesday = '$wednesday',thursday = '$thursday',friday = '$friday',saturday = '$saturday',sunday = '$sunday', ictr_id = '$ictr_id' WHERE weeks_id = '$weeks_id'";
                                    $resupweeks = mysqli_query($connect, $sqlupweeks) OR DIE(mysqli_error());
                                    if($resupweeks){}
                                }
                            }
                            else{
                                $sqladdweeks_id = "INSERT INTO instructor_weeks(instask_id,timesheet_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,ictr_id) VALUES ('$task_id','$timesheet_id','$monday','$tuesday','$wednesday','$thursday','$friday','$saturday','$sunday','$ictr_id')";
                                $resaddweeks_id = mysqli_query($connect, $sqladdweeks_id) OR DIE(mysqli_error());
                                if($resaddweeks_id){
//                                    $sqlweeks_id = "SELECT weeks_id FROM instructor_weeks iw , instructor_timesheet itm , instructor_tasks itk WHERE iw.ictr_id = '$ictr_id' AND itm.start_date = '$dateselected' AND itk.instask_id = '$task_id' AND iw.timesheet_id = itm.timesheet_id AND iw.instask_id = itk.instask_id";
//                                    $resweeks_id = mysqli_query($connect, $sqlweeks_id) OR DIE(mysqli_error());
//                                        if($resweeks_id->num_rows >= 1){ //mysqli
//                                            while($rowweeks_id = $resweeks_id->fetch_array(MYSQLI_BOTH)){ //mysqli
//                                                $weeks_id = $rowweeks_id['weeks_id'];
//                                            }
//                                        }
                                }
                            }
//                        $sqlupweeks = "UPDATE instructor_weeks SET monday = '$monday',tuesday = '$tuesday',wednesday = '$wednesday',thursday = '$thursday',friday = '$friday',saturday = '$saturday',sunday = '$sunday',ictr_id = '$ictr_id' WHERE weeks_id = '$weeks_id'";
//                        $resupweeks = mysqli_query($connect, $sqlupweeks) OR DIE(mysqli_error());
//                        if($resupweeks){}
                        $sqlupcomment = "UPDATE instructor_timesheet SET comment = '$comment' WHERE start_date = '$dateselected'";
                        $resupcomment = mysqli_query($connect, $sqlupcomment) OR DIE(mysqli_error());
                        if($resucomment){}
                   }
             }
             header('Location: home.php');
         }
         else{
            $sqladdstart = "INSERT INTO instructor_timesheet(start_date , comment) VALUES('$dateselected' , '$comment')";
            $resaddstart = mysqli_query($connect, $sqladdstart) OR DIE(mysqli_error());
            if($resaddstart){
                for($a=1;$a<$taskrows;$a++){
                   $task_id = $_POST["taskid$a"];
                   $task_name = $_POST["taskname$a"];
                   $monday = $_POST["monday$a"];
                   $tuesday = $_POST["tuesday$a"];
                   $wednesday = $_POST["wednesday$a"];
                   $thursday = $_POST["thursday$a"];
                   $friday = $_POST["friday$a"];
                   $saturday = $_POST["saturday$a"];
                   $sunday = $_POST["sunday$a"];
                   $sqlstart = "SELECT timesheet_id FROM instructor_timesheet WHERE start_date = '$dateselected'";
                   $resstart = mysqli_query($connect, $sqlstart) OR DIE(mysqli_error());
                   if($resstart->num_rows >= 1){ //mysqli
                     while($rowstart = $resstart->fetch_array(MYSQLI_BOTH)){ //mysqli
                        $timesheet_id=$rowstart['timesheet_id'];
//                        echo $a.'-task:'.$task_id.$task_name.'-timesheet'.$timesheet_id.'-monday:'.$monday.'----';
                     }
                   }
                $sqladdweeks = "INSERT INTO instructor_weeks(instask_id,timesheet_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,ictr_id) VALUES ('$task_id','$timesheet_id','$monday','$tuesday','$wednesday','$thursday','$friday','$saturday','$sunday','$ictr_id')";
                $resaddweeks = mysqli_query($connect, $sqladdweeks) OR DIE(mysqli_error());
                if($resaddweeks){}
              }
            }
            header('Location: home.php');
           }
 }       
 else{   
?>
<!doctype>
<html>
    <head>
        <?php head_lib();
            nav_style();?>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.3/js/bootstrap-datetimepicker.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.3/css/bootstrap-datetimepicker.min.css">
        <script src="jquery.js"></script>
        <script>
 $(function () {
   var bindDatePicker = function() {
		$(".date").datetimepicker({
        format:'YYYY-MM-DD',
			icons: {
				time: "fa fa-clock-o",
				date: "fa fa-calendar",
				up: "fa fa-arrow-up",
				down: "fa fa-arrow-down"
			}
		}).find('input:first').on("blur",function () {
			// check if the date is correct. We can accept dd-mm-yyyy and yyyy-mm-dd.
			// update the format if it's yyyy-mm-dd
			var date = parseDate($(this).val());

			if (! isValidDate(date)) {
				//create date based on momentjs (we have that)
				date = moment().format('YYYY-MM-DD');
			}

			$(this).val(date);
		});
	}
   
   var isValidDate = function(value, format) {
		format = format || false;
		// lets parse the date to the best of our knowledge
		if (format) {
			value = parseDate(value);
		}

		var timestamp = Date.parse(value);

		return isNaN(timestamp) == false;
   }
   
   var parseDate = function(value) {
		var m = value.match(/^(\d{1,2})(\/|-)?(\d{1,2})(\/|-)?(\d{4})$/);
		if (m)
			value = m[5] + '-' + ("00" + m[3]).slice(-2) + '-' + ("00" + m[1]).slice(-2);

		return value;
   }
   
   bindDatePicker();
 });

        </script>
    </head>
    <body>
        <?php navbar_i(); ?>
    <div class="container">

            <div class="row">
            <div class="col-md-12">
                
                <div class="box"><div class="title">Time sheet</div>
                    <div class="body">
                        <ul class="list-group">
                            <li class="list-group-item" style="font-size: 20px;">
                        <!--/////////////////////////////////////////////-->
                        <div class="row">
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            </form>
                            
                        </div> 
                        <div class="row">
                                                        <div class="form-group">
                                        <label class="control-label col-sm-3" >Change date to:</label>
                                        <div class='col-sm-6'>
                                                <div class='input-group date' id='datetimepicker1'>
                                                    <input name="datepk" id="datepk" type='text' value="<?php echo date('m/d/Y',time()+( 1 - date('w'))*24*3600);?> 10:51 AM" class="form-control" />
                                                    <span class="input-group-addon">
                                                        <span class="glyphicon glyphicon-calendar"></span>
                                                    </span>
                                                </div>
                                                <input type="hidden" id="getictr" name="getictr" value="<?php echo $ictr_id?>" class="form-control" />
                                        </div>
                                        <script type="text/javascript">
                                            $('#datetimepicker1').datetimepicker({
                                                daysOfWeekDisabled: [0,2,3,4,5,6],
                                                maxDate: new Date() 
                                            });
                                        </script>
                                        <div class="col-sm-3"><button id="cdate" class="btn btn-block btn-info">Enter Your Time</button></div>
                            </div>
                            <!--<input type="text" name="daterange" id="dateranger" value="2017/01/01 1:30 PM - 2017/01/01 2:00 PM" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%" readonly/>-->
                            
                        </div>
                        <!--////////////////////////////////////////////-->
                        
                            </li>
                            </ul>
                        <div id="taskarea">
                                <h2>
                                <!--<span class="label label-default"><?php echo "Date Today : " . date("Y-m-d") . "";?></span>-->
                                <span class="label label-default"><?php echo "Date showing : Not Selected";?></span>
                                </h2>
                            <br/> 
                            <div class="jumbotron" style="text-align: center;">
                                <h1>Nothing to Show!</h1>
                                <p>Please make a selection.</p>
                              </div>
                        </div>
                    </div>
                </div>    
            </div>
        </div> <!-- row end -->
    </div>
    </body>
</html>
<?php
}
 } else{
	header('Location: index.php');
}?>