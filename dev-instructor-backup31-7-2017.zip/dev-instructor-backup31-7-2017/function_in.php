<?php
/*
 * 1.common PHP files
 * 2.Head_lib 
 * 3.Nav_style and script
 * 3.Navigation
 * Redirect
 * .Coding classes
 * .Robotics classes
 *   
 */
/* Common PHP files */
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);
function com_php(){
    include ''; 
}

/* Header */
function head_lib(){
?>
<title>Zebra Robotics </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<script src="jquery.js"></script>
<script src="script.js"></script>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/jpg"  href="picture_library/Zebra_logo_100.jpg">
<link rel="stylesheet" type="text/css" href="style_in.css">
<?php
}
/* nav_style and script  */
function nav_style(){
?>
 <script>
            (function($){
	$(document).ready(function(){
		$('ul.dropdown-menu [data-toggle=dropdown]').on('click', function(event) {
			event.preventDefault(); 
			event.stopPropagation(); 
			$(this).parent().siblings().removeClass('open');
			$(this).parent().toggleClass('open');
		});
	});
})(jQuery);
    </script>
<style>
        body {
            background-color: white !important;
            height: 90vh !important;
        }
        .w {
                height: 60px;
                margin-top: 0px;
                padding: 10 10 10 5;
        }
        .nav>li>a:focus, .nav>li>a:hover {
            text-decoration: none;
            background: #0e85b5;
            color: #fff;
        }
        .nav .open>a, .nav .open>a:focus, .nav .open>a:hover {
            background-color: #fff;
            border-color: #fff;
            color: #000;
        }
        .dropdown-menu>li>a:focus, .dropdown-menu>li>a:hover {
            color: #ffffff;
            text-decoration: none;
            background-color: #059fd8;
        }
        a{
                color: white;
        }
        a:link{
                text-decoration: none; 
        }
        @font-face {
            font-family: lithos;
            src: url(../font/Lithos-Pro-Light_28557.ttf);
        }
</style>
<?php
}

/* Navigation */

function navbar_i(){
 ?>
<div class="row" style="padding: 10px 0px;margin:0px !important; background-color: rgb(255, 255, 255);">
                <div class="col-md-3" style="margin-top: 3px;" >
                    <a href="a_home.php" style="font-family:lithos;font-size: 30px;color:#03aeed">ZebraRobotics</a>
                </div>
            <div class="col-md-6 text-left"></div>
            <div class="col-md-3 text-left" style="color: black;">
                <div style="margin-top:6px; font-size: 26px;">
                    Hi, <?php echo $_SESSION['t_first']; ?>
                    <a href="tdestroy.php"  class="btn btn-info" style="margin-left:20px;margin-top: -2px;background-color: white; color:black;">
                        <span class="glyphicon glyphicon-log-out"> </span> Logout 
                    </a>
                </div>
            </div>
        </div>
        <nav class="navbar" style="background: #059fd8;border-color: transparent;border-radius: 0px;" >
            <div class="container-fluid" >
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">

                    <!-- <a class="navbar-brand" href="a_home.php"><b>Zebra Robotics</b></a> -->
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li><a href="home.php">Home</a></li>
                        <li><a href="ins_attendance.php">Attendance</a></li>
                         <li><a href="ins_challenge_score.php">Challenge Score</a></li>
                        <li><a href="ins_challenge_detail.php">Challenge Details</a></li>
                        <li><a href="addtask.php">Manage Courses</a></li>
                        <!--<li><a href="addreport.php">Add New Report</a></li>-->
<!--                        <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Parent <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                        <li>
                                                <a href="ins_parent.php">Insert Parent</a>
                                        </li>
                                        <li>
                                                <a href="upd_parent.php">Update Parent Record </a>
                                        </li>
                                </ul>
                        </li>-->
                    </ul>
                </div><!-- /.navbar-collapse -->

            </div><!-- /.container-fluid -->
        </nav>
<?php
}
function redirect($url){
    header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    header("Cache-Control: no-cache");
    header("Pragma: no-cache");
    if (headers_sent()) { 
        die("Redirect failed.");
    }else{
        exit(header("Location: $url"));
    }   
}