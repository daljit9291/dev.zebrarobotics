<?php 
ob_start();
session_start();
include 'function_in.php';
include 'config.php';
if (!empty($_SESSION['t_id'])) 
    {  
        $sql_c =  "SELECT * FROM course"; //mysqli
        $res_c = mysqli_query($connect,$sql_c) OR die(mysqli_error());
    ?>
        <!doctype html> 
        <html>
            <head><?php head_lib();?>
                <style>
                    .titl{
                         background-color: rgb(205, 119, 119)!important;
                    }
                </style>
            </head>
            <body> 
            <?php nav_style();navbar_i(); ?>
                <div class="container">
                    <div class="box" style="width:70%;">
                        <div class="title">Insert Challenge Details</div>
                        <form method="POST" id ="in_ch_d" class="form-horizontal" role="form" style="padding:2%;padding-top: 4%;padding-right: 5%;">
                        <div class="form-group">
                            <label class="control-label col-sm-3" >Select Course:</label>
                            <div class="col-sm-3">
                                <select class="form-control" id="cid" name="scl_course">
                                    <option value="none">--- Select Course ---</option>
                                    <?php while($row = $res_c->fetch_array(MYSQLI_BOTH)){
                                        $cid = $row['course_id'];
                                        $cnm= $row['course_name'];
                                        echo "<option value='$cid'>$cnm</option>";
                                    } ?>
                                </select>
                            </div>
                            <label class="control-label col-sm-3" >Select level :</label>
                            <div class="col-sm-3">
                                <select class="form-control" id="clid" name="scl_cr_cl">
                                    <option value="none">Select Course Level</option>
                                    
                                </select>
                            </div>  
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-3" >Challenge Number:</label>
                            <div class="col-sm-3">
                                <input type="text" name="ch_number" id="ch_num" class="form-control num" ></div>
                            
                            <label class="control-label col-sm-3" >Challenge Score:</label>
                            <div class="col-sm-3">
                                <input type="text" class="form-control num" name="ch_score" placeholder=""></div>
<!--                            <label class="control-label col-sm-2" >Challenge Number:</label>
                            <div class="col-sm-7">
                            <div class="col-sm-3"></div>-->
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-3" >Challenge Description:</label>
                            <div class="col-sm-6"><textarea class="form-control" rows="2" name="ch_desc"></textarea></div>
                            <div class="col-sm-3"></div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-3" >Challenge Type:</label>
                            <div class="col-sm-6">
                                <label class="radio-inline"><input type="radio" name="ch_type" value="quiz">Quiz</label>
                                <label class="radio-inline"><input type="radio" name="ch_type" value="class">Class</label>
                            </div>
                            <div class="col-sm-3"></div>
                        </div>
<!--                        <div class="form-group">
                            <label class="control-label col-sm-2" >Challenge Score:</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control" name="ch_score" placeholder=""></div>
                            <div class="col-sm-3"></div>
                        </div>-->
                        <div class="form-group">
                            <label class="control-label col-sm-3" >Challenge Category:</label>
                            <div class="col-sm-6">
                                <label class="radio-inline"><input type="radio" name="ch_cat" value="programming">Programming</label>
                                <label class="radio-inline"><input type="radio" name="ch_cat" value="mechanic">Mechanic</label></div>
                            <div class="col-sm-3"></div>
                        </div>
                        <div class="form-group">        
                            <div class="col-sm-offset-3 col-sm-9">
                            <button type="submit" class="btn btn-primary btn-lg active" name="upload" >Submit</button> 
                        </div>
                        </div>
                    </form>
                    </div> 
                </div>

    <?php
    }else{
        redirect('a_login.php');
    }  
?>