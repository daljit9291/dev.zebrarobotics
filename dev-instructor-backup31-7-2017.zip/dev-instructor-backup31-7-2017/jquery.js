/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function(){
$('.num').keyup(function () { 
    this.value = this.value.replace(/[^0-9\.]/g,'');
});
$('body').on('change','#dateranger',function(e){ 
//$('#dateranger').change(function(e){
             e.preventDefault();
             var dc = $(this).val();
                $.ajax({ 
                type : "POST",   
                url : "get_info.php",             
                data : {dc: dc},
                success : function(html) { 
                    $("#dc").html(html);
                },
                error : function(error){
                    alert(error);
                }
            });
    });
    $('body').on('click','#cdate',function(e){ 
//$('#dateranger').change(function(e){
             e.preventDefault();
             var dp = $("#datepk").val();
             var getictr = $("#getictr").val();
//             dp = "hi";
                $.ajax({ 
                type : "POST",   
                url : "get_info.php",             
                data : {dp: dp , getictr: getictr },
                success : function(html) { 
                    $("#taskarea").html(html);
                },
                error : function(error){
                    alert(error);
                }
            });
    });
        $('body').on('click','.deltask',function(e){ 
//$('#dateranger').change(function(e){
             e.preventDefault();
             var deltask_id = $(this).attr('data-taskdid');
             var deltask_name = $(this).attr('data-taskdname');
//             alert(deltask_name);
                $.ajax({ 
                type : "POST",   
                url : "get_info.php",             
                data : {deltask_id: deltask_id , deltask_name: deltask_name },
                success : function(html) {
                    alert("Deleted Successfully!");
                    $(location).attr('href', 'addtask.php');
//                    $("#dpk").html(html);
                },
                error : function(error){
                    alert(error);
                }
            });
    });
            $('body').on('click','.edittask',function(e){ 
//$('#dateranger').change(function(e){
             e.preventDefault();
             var edittask_id = $(this).attr('data-taskedid');
             var edittask_name = $(this).attr('data-taskedname');
//             alert(deltask_name);
                $.ajax({ 
                type : "POST",   
                url : "get_info.php",             
                data : {edittask_id: edittask_id , edittask_name: edittask_name },
                success : function(html) {
//                    alert("updated Successfully!");
//                    $(location).attr('href', 'addtask.php');
//                    $("#modal").html(html);
                        $("#oldtaskid").val(edittask_id);
                       $("#oldtaskname").val(edittask_name);
                       $("#newtaskname").val(edittask_name);
                },
                error : function(error){
                    alert(error);
                }
            });
    });
// Get Student list for attendance
//    $('body').on('change','#get_bid',function(e){ 
//        var bid = $('#get_bid option:selected').val();
//        if(bid ==='none'){
//            alert('select batch !');
//        }else{
//            $('.c_date').removeAttr('disabled');
//            $.ajax({ 
//        type : "POST",   
//        url : "get_info.php",             
//        data : {bch_id_s_list:bid},
//        success : function(html) {
//            $('#std_list').html(html);
//        },
//        error : function(error){
//            alert(error);
//        }
//        });
//            
//        }
//        
//    });
    $('body').on('change','.c_date',function(e){
       var dt = $(this).val();
       $('.t_date').attr('value',dt);
       $('#date_top').html('<span class="label label-default red">Selected Date : '+dt+'</span>');
       
       alert('Attandance date has been changed !');
    });
// Insert Attendance     
    $('body').on('submit','.student_att',function(e){ 
        e.preventDefault();
                var form = $(this).serialize();
                var std_id = $("input[name='std_id']",this).val();  
            $.ajax({ 
                type : "POST",   
                url : "get_info.php",             
                data : form,
                success : function(html) {
//                    console.log(html);
                    if(html == 1){
                        $('.tic'+std_id).html('<img src="tick.png" style="height: 38px;width: 38px;margin: 0px 26%;">');
                    }else if(html == 3){
                        $('.tic'+std_id).html('Updated !');
                    }else{
                            alert(html);
                        }
                    },
                    error : function(error){
                        alert(error);
                    }
        });

    });
// Get Student list for enter challenge Score 
    $('body').on('change','#get_bid_ch',function(e){ 
        var bid = $('#get_bid_ch option:selected').val();
        var text_bid = $('#get_bid_ch option:selected').text();
//        alert(text_bid);
        if(bid ==='none'){
            alert('select batch !');
        }else{
            window.location='ins_challenge_score.php?select_bid='+bid+'&so='+text_bid;

        }
        
    }); 
// Insert Challenge details page
    $('body').on('change','#cid',function(e){ 
        var cid = $('#cid option:selected').val();
//        var text_bid = $('#get_bid_ch option:selected').text();
//        alert(cid);
        if(cid ==='none'){
            alert('select Course !');
        }else{
            $.ajax({ 
                type : "POST",   
                url : "get_info.php",             
                data : {sec_cid:cid},
                success : function(html) {
                   $('#clid').html(html);
                    }

        });
    }
    });
// Check challenge number exits or not    
    $('body').on('change','#ch_num',function(e){ 
        var ch_num = $(this).val();
        var cl_id = $('#clid').val();
        $.ajax({ 
                type : "POST",   
                url : "get_info.php",             
                data : {check_cl:cl_id,check_ch_num:ch_num},
                success : function(html) {
                    if(html == 0 ){
                        swal({
                            title: "Duplicate Value ! ",
                            text: " Challenge Number already exits for this course level.",
                            type: "error",
                            showCancelButton: false,
                            confirmButtonColor: "#DD6B55",
                            confirmButtonText: "Try again",
                            cancelButtonText: "",
                            closeOnConfirm: false,
                            closeOnCancel: false
                          },
                          function(isConfirm){
                            if (isConfirm) {
//                                $('#ch_num').val('');
                              window.location.href = "ins_challenge_detail.php"; 
                            } 
                        });
                    }else{
                        
                    }
                }
            });
        
    });
// Insert Challenge detail record form value
    $('body').on('submit','#in_ch_d',function(e){ 
            e.preventDefault();
            var form = $(this).serialize();
            console.log(form);
            $.ajax({ 
                type : "POST",   
                url : "get_info.php",             
                data : form,
                success : function(html) {
                    if(html == 1){
                        swal({
                        title: "Challenge Details Added !",
                        text: "",
                        type: "success",
                        showCancelButton: false,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "Done",
                        cancelButtonText: "",
                        closeOnConfirm: false,
                        closeOnCancel: false
                        },
                        function(isConfirm){
                          if (isConfirm) {
                            window.location.href = "ins_challenge_detail.php"; 
                          } 
          //                else {
          //                  window.location.href = "home.php"; 
          //                }
                        });
                    }else{
                       swal("Somthing went wrong!",html, "error");
                    }
                }
            });
            
    });
// Challenge Score submit form
//$('body').on('change','.chkbox :checkbox',function(e){ 
$('#ch_form :checkbox').change(function() {   
    if (this.checked) {
        $(this).attr('value','1');
    } else { 
        $(this).attr('value','0');
    }
});
 $('body').on('submit','#ch_form',function(e){ 
            e.preventDefault();
            var form = $(this).serialize();
            console.log(form);
            $.ajax({ 
                type : "POST",   
                url : "get_info.php",             
                data : form,
                success : function(html) {
                    if(html == 1){
                        swal({
                        title: "Challenge Score Updated !",
                        text: "",
                        type: "success",
                        showCancelButton: false,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "Go Back",
                        cancelButtonText: "",
                        closeOnConfirm: false,
                        closeOnCancel: false
                        },
                        function(isConfirm){
                          if (isConfirm) {
                            parent.history.back(); 
                          } 
                        });
                    }else{
                       swal("Somthing went wrong!",html, "error");
                    }
                }
            });
        });
});

