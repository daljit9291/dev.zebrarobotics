<?php 
ob_start();
session_start();
include 'function_in.php';
include 'config.php';
if (!empty($_SESSION['t_id'])) 
    {  
        $sql =  "SELECT * FROM batch b, course c WHERE active='Y'"
            . "AND b.course_id = c.course_id"; //mysqli
        $res = mysqli_query($connect,$sql) OR die(mysqli_error());
    ?>
        <!doctype html> 
        <html>
            <head><?php head_lib();?>
                <style>
                    .titl{
                         background-color: rgb(205, 119, 119)!important;
                    }
                </style>
            </head>
            <body> 
            <?php nav_style();navbar_i(); ?>
                <div class="container">
                    <div class="box" style="width:90%; padding-bottom: 2%;">
                        <div class="title">Challenge Score</div>
                <div class="row" style="padding-top: 25px;margin: 1% 0px;">
                    <div class="col-md-4">
                        <div class="form-group form-inline">
                            <label for="sel1" style="float:left; padding:7px;">Select Batch:</label>
                            <div class="dropdown" style="float:left;width:64%;">
                                <button class="btn btn-black dropdown-toggle" type="button" data-toggle="dropdown" style="width:100%;"><?php 
                                if(isset($_GET['cn'])){
                                echo $_GET['cn'];
                                echo "<script>"
                                . "$(document).ready(function(){
                                    $('.c_date').removeAttr('disabled');});</script>";
                                }else{
                                    echo "Select Batch";
                                }
                                ?>
                                    <span class="caret" style="float: right;margin-top: 9px;"></span></button>
                            <ul class="dropdown-menu">
                            
                        <!--<select class="form-control" id="get_bid" style="width:50%; margin-left: 15px;">-->
                            <!--<option value="none">---------- Select Batch ----------</option>-->
                            <?php
                                while($row = $res->fetch_array(MYSQLI_BOTH)){
                                    $bid = $row['batch_id'];
                                    $cn = $row['course_name'];
                                    echo "<li><a href='ins_challenge_score.php?bid=$bid&cn=$cn'>$bid (".$row['course_name'].")</a></li>";
//                                    echo "<option value=".$row['batch_id'].">".$row['batch_id']." (".$row['course_name'].")</option>";
                                }
                            ?>
                            </ul>
                        </div>
                           <!--</select>-->
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group form-inline">
                        <label for="sel1"> Change Date:</label>
                        <input type="date" class="form-control c_date" name="att_date" disabled="true">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div id="date_top"><span class="label label-default">Today : <?php echo date("Y-m-j"); ?></span></div>
                    </div>

                </div>
                <?php
                if(isset($_GET['se_bid'])){
                    $bid = $_GET['se_bid'];
                    $sid = $_GET['sid'];
                    $sql_s ="SELECT * FROM student WHERE student_id ='$sid'";
                    $res_s = mysqli_query($connect, $sql_s) or die(mysqli_error($connect));
                    while($row_s = $res_s->fetch_array(MYSQLI_BOTH)){
                        $s_nam = $row_s['first_name']." ".$row_s['last_name'];
                    }
                    $sql = "SELECT ch.challenge_id, ch.challenge_nbr FROM course_level cl, course c, batch b, challenges ch"
                            . " WHERE cl.course_id = c.course_id "
                            . "AND c.course_id = b.course_id "
                            . "AND b.batch_id = '$bid' "
                            . "AND ch.course_level_id = cl.course_level_id";
                    $res= mysqli_query($connect, $sql) or die(mysqli_error($connect));
                    $cnt = mysqli_num_rows($res);
                        if($cnt == '0'){
                           echo "<h2>No Challenge Found !</h2>"; 
                        }else{
                            $i=1;?>
                        <div class="main" style="padding-bottom:20px;">
                            <div class="ttl" style="height: 60px;font-size: 22px;">
                                <div style="float:left;">Student Name : <?php echo $s_nam; ?> </div>
                                <div style="float:right;">Student Id : <?php echo $sid; ?></div>
                            </div>
                            <form id="ch_form" method="POST" role="form">
                                <input type="hidden" name="ch_tot" value="<?php echo $cnt;?>">
                                <input type="hidden" name="ch_sid" value="<?php echo $sid;?>">
                                <input type='hidden' name='t_date' class='t_date' value='<?php echo date('Y-m-j '); ?>' />
                            <table class="table table-bordered table-striped"  style="margin-top:4%;margin-bottom: 4%;width: 40%;margin-left: 30%;margin-right: 30%;">
                                <thead>
                                    <tr style="font-size:large; text-align: center;">
                                        <th>Challenge Number</th><th>Complete</th>
                                    </tr>
                                </thead>
                                <tbody> 
                            <?php while($row = $res->fetch_array(MYSQLI_BOTH) ){
                                $chid=$row['challenge_id'];
                                $sql_scs = "SELECT * FROM student_class_score WHERE challenge_id ='$chid' AND student_id='$sid'";
                                $res_scs = mysqli_query($connect, $sql_scs) or die(mysqli_error($connect));
                                $cnt = mysqli_num_rows($res_scs);
                                $row1 = $res_scs->fetch_array(MYSQLI_BOTH);
                                if($cnt == '1'){
                                    $st = 'checked';
                                    $val = 2;
                                }else{ 
                                    $st='';
                                    $val = 0;
                                }
                                echo "<tr style='text-align:center;'><td>".$row['challenge_nbr']."<input type='hidden' name='ch_id$i' value=".$row['challenge_id']." >"
                                        . "<input type='hidden' name='ch_sr$i' value=".$row1['st_sore_id']." ></td>"
                                        . "<td><input type='checkbox' class='chkbox' name='ch_chk$i' value='$val' $st></td></tr>";
                                $i++;
                            } ?>
                                    <tr><td></td><td style='text-align:center;'><button type="submit" class="btn btn-black" name="submit">Submit</button></td></tr>
                                </tbody>  
                            </table>
                            </form>
                        </div>
                  <?php }    
                }
                else if(isset($_GET['bid'])){
                        $stud_bch_id = $_GET['bid'];
                        $cn = $_GET['cn'];
                        $sql_student = "SELECT * FROM student_batch b, student s WHERE batch_id='$stud_bch_id'"
                                . "AND b.student_id = s.student_id";
                        $res_student= mysqli_query($connect, $sql_student);
                        $count = mysqli_num_rows($res_student);
                        if($count == '0'){
                           echo "<h2>No Record Found !</h2>"; 
                        }else{ ?>
                        <div style="padding: 20px 0px;border-top: 2px solid #dddddd;">
                            <table class="table table-bordered table-striped"  style="width: 70%;margin-left: 15%;">
                                <thead>
                                    <tr style="font-size:large;">
                                        <th>Student id</th><th>Name</th><th>Score</th>
                                    </tr>
                                </thead>
                                <tbody> <?php 
                                while($row = $res_student->fetch_array(MYSQLI_BOTH)){ 
                                    $sid=$row['student_id'];
                                    echo "<tr><td>".$row['student_id']."</td>"
                                            . "<td>".$row['first_name']." ".$row['last_name']."</td>"
                                            . "<td>
                                                <input type='hidden' name='std_id' class='std_id' value='".$row['student_id']."' />
                                                <input type='hidden' name='t_date' class='t_date' value='".date(' Y-m-j ')."' />
                                                    <a href='ins_challenge_score.php?se_bid=$stud_bch_id&sid=$sid&cn=$cn' class='btn btn-black'>Enter Score</a>
                                                </form></td>"
                                        . "</tr>";
                                    echo "";
                                } ?>
                                </tbody>
                            </table>
                        </div>
                         <?php
                        }
                    }
                ?>
                    <div id="std_list"></div>
                    </div>
                </div>
            </body>
        </html>
    <?php
    }else{
        redirect('a_login.php');
    } 
?>