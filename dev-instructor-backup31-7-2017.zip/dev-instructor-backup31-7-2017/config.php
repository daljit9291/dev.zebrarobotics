<?php 
$host="50.116.79.85:3306"; // Host name 
$username = "zebrarob_ms";
$password = "321ms";
$db_name="zebrarob_zrc"; // Database name  
///-----mysql connect
// mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
// mysql_select_db("$db_name")or die("cannot select DB");
// try {
// $dbh = new PDO("mysql:host=$host;dbname=$db_name","$username","$db_name");
// } catch (Exception $e) {
// die("<p>{$e->getMessage()} </p></body> </html>");
// }

///------mysqlI connect
 $connect = mysqli_connect("$host", "$username", "$password", "$db_name");
 
 if (!$connect) {
     echo "Error: Unable to connect to MySQL." . PHP_EOL;
     echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
     echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
     exit;
 }
// 
// echo "Success: A proper connection to MySQL was made! The my_db database is great." . PHP_EOL;
// echo "Host information: " . mysqli_get_host_info($connect) . PHP_EOL;


///---- pdo connect
//try {
//    $dbh = new PDO('mysql:host=50.116.79.85;dbname=zebrarob_zrc', $username, $password);
////    foreach($dbh->query('SELECT * from login') as $row) {
////        print_r($row);
//    }
//    $dbh = null;
//} catch (PDOException $e) {
//    print "Error!: " . $e->getMessage() . "<br/>";
//    die();
//} 
?>