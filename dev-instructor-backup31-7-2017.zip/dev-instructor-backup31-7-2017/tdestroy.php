<?php 
session_start();
session_destroy(); 
header('Location: index.php');
setcookie("ictr_id","no",time()-1);
//setcookie("pass","no",time()-1);
?>