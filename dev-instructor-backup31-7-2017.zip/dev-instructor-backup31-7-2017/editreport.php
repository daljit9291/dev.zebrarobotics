<?php
session_start();
include 'config.php';
include 'function_in.php';
if (!empty($_SESSION['t_id'])) {
    $ictr_id = $_SESSION['t_id'];
    if (isset($_POST["edit"])) {
        $task = $_POST["task"];
        $desc = $_POST["desc"];
        $datepk = $_POST["datepk"];
        $hours = $_POST["hours"];
//     $sqladd = "INSERT INTO instructor_task(date , task , desc) VALUES ($datepk , $task , $desc)";
//     $resadd = mysql_query($sqladd) OR DIE(mysql_error());
        $sqledit = " UPDATE instructor_task SET task='$task' , desc_i = '$desc' , hours = '$hours' , pres = 'Y' WHERE ictr_id = '$ictr_id'";
        //$sql =  "INSERT INTO instructor_task(date , task , desc_i , hours , pres , ictr_id) VALUES ('$datepk' , '$task' , '$desc' , '$hours' , 'Y' , '$ictr_id')"; //mysqli
//     $resedit= mysqli_query($connect,$sql) OR die(mysqli_error());
//     if($res){
//         header("Location: addreport.php");
//     }
        if (mysqli_query($connect, $sqledit)) {
            echo "Record updated successfully";
            header("Location: home2.php");
            exit();
        } else {
            echo "Error updating record: " . mysqli_error($connect);
        }
    } else if (isset($_POST["chg_id"])) {
        $chg_id = $_POST["chg_id"];
        $sqlshow = "SELECT * FROM instructor_task where task_id = '$chg_id'";
        $resshow = mysqli_query($connect, $sqlshow) OR die(mysqli_error());
        if ($resshow->num_rows >= 1) { //mysqli
            while (($rowshow = $resshow->fetch_array(MYSQLI_BOTH)) && $i <= 6) { //mysqli
                $stask = $rowshow['task'];
                $sdesc = $rowshow['desc_i'];
                $sdate = $rowshow['date'];
                $shours = $rowshow['hours'];
            }
        }// }
// else{
        ?>
        <!DOCTYPE html>
        <html>
            <head>
                <?php head_lib();
                nav_style();
                ?>
                <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.min.js"></script>
                <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.3/js/bootstrap-datetimepicker.min.js"></script>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.3/css/bootstrap-datetimepicker.min.css">
            </head>
            <body>
        <?php navbar_i(); ?>
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <div class="box"><div class="title">Daily Report</div>
                                <div class="body">
                                    <form method="POST" id ="dailyreport" action="<?php $_SERVER['PHP_SELF']; ?>" class="form-horizontal" role="form">
                                        <!--                            <div class="form-group">
                                                                        <label class="control-label col-sm-3" >Task:</label>
                                                                        <div class="col-sm-9">
                                                                                <input type="text" class="form-control" name="task" placeholder="Coding | Robotics | Programming" required>
                                                                            </div>
                                                                    </div>-->
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" >DATE:</label>
                                            <div class="col-sm-9">
                                                <input type="text" value="<?php echo $sdate; ?>" class="form-control" name="date" placeholder="Date" required readonly>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="task">TASK:</label>
                                            <div class="col-sm-9">
                                                <select class="form-control" id="task" name="task" required>
                                                    <option value="CODING">CODING</option>
                                                    <option value="ROBOTICS">ROBOTICS</option>
                                                    <option value="PROGRAMMING">PROGRAMMING</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" >Number Of Hours:</label>
                                            <div class="col-sm-9">
                                                <input type="text" value="<?php echo $shours; ?>" class="form-control" name="hours" placeholder="Hours" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" > Comment (Optional):</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control"  id="desc" value="<?php echo $sdesc; ?>" name="desc"/>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-offset-8 col-sm-2">

                                                <button type="submit" class="btn btn-danger btn-lg active" name="delete" >
                                                    DELETE
                                                </button>
                                            </div>
                                            <div class="col-sm-2">
                                                <button type="submit" class="btn btn-info btn-lg active" name="edit" >
                                                    EDIT
                                                </button>

                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>    
                        </div>
                    </div>
                    <!--/// row end-->
                </div>
            </body>
        </html>
        <?php
    }
} else {
    header('Location: index.php');
}
?>