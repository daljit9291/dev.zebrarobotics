<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);
ob_start();
session_start();
$error="";
if (!empty($_SESSION['t_id'])){
	header("Location: home.php");
}
else{
	header("Location: ../a_login.php");
}

if (isset($_POST['myusername'])) 
{ 
       include 'config.php';

if (isset($_POST['myusername'])){
$myusername=$_POST['myusername']; 
$mypassword=$_POST['mypassword'];
//$sql="SELECT * FROM instructor WHERE ictr_id='$myusername' and password='$mypassword'"; //mysql , mysqli
//$res=mysql_query($sql)or die(mysql_error()); //mysql , mysqli

//$sql = mysqli_query($connect, "SELECT * FROM instructor WHERE ictr_id='$myusername' and password='$mypassword'"); //mysqli
//$res= mysqli_fetch_array($sql);  //mysqli
$sql =  "SELECT * FROM instructor WHERE ictr_id='$myusername' and password='$mypassword'"; //mysqli
$res= mysqli_query($connect,$sql);
//	if(mysql_num_rows($res) == 0){  //mysql and mysqli
               
        if($res->num_rows == 1){ //mysqli
//		while($row=mysql_fetch_assoc($res)){  //mysql
 while($row = $res->fetch_array(MYSQLI_BOTH)){ //mysqli
			$_SESSION['t_id']=$row['ictr_id'];
			$_SESSION['t_first']=$row['ictr_first_name'];
			$_SESSION['t_last']= $row['ictr_last_name'];
                        
		}
	     header("Location: home.php");
             echo $_SESSION['t_id'];
	}
	else {
		$error='<div class="alert alert-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Warning!</strong> No Combination found for the UserId and Password entered !.
                </div>';
                echo $error;
	}
}
}  
else {
}
?>
<html>
 <head>
 <title>Zebra Robotics</title>
 <meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1"> 	
  	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.0/sweetalert.min.js"></script>
  	<!--<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.0/sweetalert.min.css"/>
  	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
   	<link rel="stylesheet" type="text/css" href="atstyle.css">--> 
   	<link rel="icon" type="image/jpg"  href="picture_library/Zebra_logo_100.jpg">
   	<!-- <link rel="stylesheet" type="text/css" media="(min-width:481px)" href="desktopstyle.css">
	<link rel="stylesheet" type="text/css" media="(max-width:480px)" href="mobilestyle.css"> -->

<style>
video { 
    position: fixed;
    top: 50%;
    left: 50%;
    min-width: 100%;
    min-height: 100%;
    width: auto;
    height: auto;
    z-index: -100;
    transform: translateX(-50%) translateY(-50%);
	background: url("images/keyboard.png") no-repeat;
 	background-size: cover;
  	transition: 1s opacity;
}

body {
  background-image: url("images/keyboard.png");
  background-size: 100% 100%;
  background-repeat: no-repeat;
  background-color: white;
}
#pageheader{
	/*opacity:0.9;*/
}
#lform{
	/*background-color: gray;*/
	/*opacity:0.95;*/
}
.form-signin {
  max-width: 330px;
  padding: 15px;
  margin: 0 auto;
}
.form-signin .form-signin-heading,
.form-signin .checkbox {
  margin-bottom: 10px;
}
.form-signin .checkbox {
  font-weight: normal;
}
.form-signin .form-control {
  position: relative;
  height: auto;
  -webkit-box-sizing: border-box;
          box-sizing: border-box;
  padding: 10px;
  font-size: 16px;
}
.form-signin .form-control:focus {
  z-index: 2;
}
.form-signin input[type="email"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}

	
input[type="text"],input[type="password"] {
	background-color:transparent!important;
	-webkit-box-shadow: 0 0 0px 1000px transparent inset;
	height:45px;
	font-size:35px;
	border: 1px solid #537cb0;
	padding:0px 0px 0px 5px;
	/*color:white;*/
}

.ol{
   /*color: lightblue; */
   -webkit-text-fill-color: white; /* Will override color (regardless of order) */
   -webkit-text-stroke-width: 1px;
   /*text-shadow: 0px 0px lightblue;*/
}
.ol2{
	/*text-shadow: 0px 0px lightblue;*/
}
#inputEmail, #inputPassword, #sbutton{
	background-color: transparent!important;
	/*text-shadow: 1px 1px lightblue;*/
}
#overlay {
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  z-index: 1;
  color: rgba(130, 130, 130, 0.5);
  font-size: 30px;
  text-align: center;
  line-height: 100px;
  box-shadow: 0 3px 5px rgba(0, 0, 0, 0.3);
}
#overlay2 {
  position: fixed;
  left: 32%;
  top: 140;
  width: 36%;
  z-index: -1;
  color: rgba(130, 130, 130, 0.5);
  font-size: 10px;
  text-align: center;
  line-height: 350px;
  box-shadow: 0 3px 5px rgba(0, 0, 0, 0.3);
}
</style> 
</head>
<body>
	<div id="container">
  <!-- <img src="images/keyboard.png" /> -->
  <div id="overlay">ZEBRA ROBOTICS</div>
  <svg width="450" height="100" viewBox="0 0 450 100" style="position: absolute; top: 0;">
    <defs>
      <filter id="blur">
        <feGaussianBlur in="SourceGraphic" stdDeviation="3" />
      </filter>
    </defs>
    <!-- <image filter="url(#blur)" xlink:href="images/keyboard.png" x="0" y="0" height="300px" width="450px" /> -->
  </svg>
  
    <!-- <img src="images/keyboard.png" /> -->
  <div id="overlay2">LOGIN</div>
  <svg width="34%" height="300" viewBox="0 0 450 100" style="position: absolute; top: 140; left:32%;">
    <defs>
      <filter id="blur">
        <feGaussianBlur in="SourceGraphic" stdDeviation="3" />
      </filter>
    </defs>
    <!-- <image filter="url(#blur)" xlink:href="images/keyboard.png" x="0" y="0" height="300px" width="450px" /> -->
  </svg>
</div>

	<video poster="images/keyboard.jpg" id="bgvid" playsinline autoplay muted loop>
  <!-- WCAG general accessibility recommendation is that media such as background video play through only once. Loop turned on for the purposes of illustration; if removed, the end of the video will fade in the same way created by pressing the "Pause" button  -->
<!-- <source src="http://thenewcode.com/assets/videos/polina.webm" type="video/webm"> -->
<source src="images/keyboard.mp4" type="video/mp4">
</video>
	<!-- <div id="pageheader" style="margin:0px; margin-bottom: 50px; padding-top: 10px; width: 100%; height: 100px;  background-color: seagreen;"> -->
		<div id="pageheader">
		<h2 style="margin-top:0px; text-align: right;color: white"> ZEBRA ROBOTICS</h2>
		<h4 style="margin-bottom:0px;text-align: right; color: white;"> ADMIN PANEL</h4>
	</div>
	<div class="container">
		<br /> <br /> <br />
      <form id="lform" style="border: 0px solid gray; " class="form-signin" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" role="form" >
        <h1 class="form-signin-heading ol" style="text-align: center; color: white; font-weight: 400!important ;">Login
        	<!-- <h4 style="text-align: center;" class="ol"> || Admin ||</h4> -->
        	</h1>
        	<br />
        <!-- <input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
        <input type="password" id="inputPassword" class="form-control" placeholder="Password" required>
         -->
        <div class="form-group">
     		 <input type="text" id="inputEmail" class="form-control ol2" name="myusername" placeholder="UserID" style=" color: white;border: 0.5px solid gray;" required autofocus  >
    	</div>
		<div class="form-group">
      		<input type="password" id="inputPassword" class="form-control ol2"  name="mypassword" placeholder="Password" style="border: 0.5px solid gray;"  required>
    	</div>
        <button id="sbutton" class="form-control" style="border: 0px solid black; color: white;" class="btn btn-lg btn-success btn-block ol2" value="login" type="submit"><span class="glyphicon glyphicon-user"></span> &nbsp; <span class="glyphicon glyphicon-log-out" ></span> </button>
        
      </form> 
	<div id="mobileshow">
            <?php  ?><br>
	  </div>
	  </div>
</body>
</html>
