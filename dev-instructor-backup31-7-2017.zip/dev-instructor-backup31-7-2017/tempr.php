<?php
session_start();
include 'config.php';
include 'function_in.php';
if (!empty($_SESSION['t_id'])) {
    $ictr_id = $_SESSION['t_id'];
 if (isset($_POST["add"])) {
     $task = $_POST["task"];
     $desc = $_POST["desc"];
     $datepk = $_POST["datepk"];
     $hours = $_POST["hours"];
//     $sqladd = "INSERT INTO instructor_task(date , task , desc) VALUES ($datepk , $task , $desc)";
//     $resadd = mysql_query($sqladd) OR DIE(mysql_error());
     $sql =  "INSERT INTO instructor_task(date , task , desc_i , hours , pres , ictr_id) VALUES ('$datepk' , '$task' , '$desc' , '$hours' , 'Y' , '$ictr_id')"; //mysqli
     $res= mysqli_query($connect,$sql) OR die(mysqli_error());
     if($res){
         header("Location: addreport.php");
     }
 }       
 else{   
?>
<!doctype>
<html>
    <head>
        <?php head_lib();
            nav_style();?>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.3/js/bootstrap-datetimepicker.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.3/css/bootstrap-datetimepicker.min.css">
        <script src="jquery.js"></script>
        <script>
 $(function () {
   var bindDatePicker = function() {
		$(".date").datetimepicker({
        format:'YYYY-MM-DD',
			icons: {
				time: "fa fa-clock-o",
				date: "fa fa-calendar",
				up: "fa fa-arrow-up",
				down: "fa fa-arrow-down"
			}
		}).find('input:first').on("blur",function () {
			// check if the date is correct. We can accept dd-mm-yyyy and yyyy-mm-dd.
			// update the format if it's yyyy-mm-dd
			var date = parseDate($(this).val());

			if (! isValidDate(date)) {
				//create date based on momentjs (we have that)
				date = moment().format('YYYY-MM-DD');
			}

			$(this).val(date);
		});
	}
   
   var isValidDate = function(value, format) {
		format = format || false;
		// lets parse the date to the best of our knowledge
		if (format) {
			value = parseDate(value);
		}

		var timestamp = Date.parse(value);

		return isNaN(timestamp) == false;
   }
   
   var parseDate = function(value) {
		var m = value.match(/^(\d{1,2})(\/|-)?(\d{1,2})(\/|-)?(\d{4})$/);
		if (m)
			value = m[5] + '-' + ("00" + m[3]).slice(-2) + '-' + ("00" + m[1]).slice(-2);

		return value;
   }
   
   bindDatePicker();
 });

        </script>
    </head>
    <body>
        <?php navbar_i(); ?>
<!--        <div class="container">

           
                <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="box"><div class="title">Daily Report</div>
                    <div class="body">
                        <form method="POST" id ="dailyreport" action="<?php $_SERVER['PHP_SELF']; ?>" class="form-horizontal" role="form">
                            <div class="form-group">
                                        <label class="control-label col-sm-3" >Day:</label>
                                        <div class='col-sm-6'>
                                                <div class='input-group date' id='datetimepicker1'>
                                                    <input name="datepk" type='text' class="form-control" />
                                                    <span class="input-group-addon">
                                                        <span class="glyphicon glyphicon-calendar"></span>
                                                    </span>
                                                </div>
                                            
                                        </div>
                                        <script type="text/javascript">
                                            $(function () {
                                                $('#datetimepicker1').datetimepicker();
                                            });
                                        </script>
                                    
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3" >Task:</label>
                                <div class="col-sm-9">
                                        <input type="text" class="form-control" name="task" placeholder="Coding | Robotics | Programming" required>
                                    </div>
                            </div>
                                                        <div class="form-group">
                                <label class="control-label col-sm-3" >Number Of Hours:</label>
                                <div class="col-sm-9">
                                    <input type="number" min="0" max="9999" class="form-control" name="hours" placeholder="Hours" required>
                                    </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3" > Description:</label>
                                <div class="col-sm-9">
                                        <textarea class="form-control" rows="5" id="desc" name="desc"></textarea>
                                    </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-offset-8 col-sm-4">
                                    <button type="submit" class="btn btn-primary btn-lg active" name="add" >
                                        Submit
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>    
            </div>
            </div>
        /// row end
    </div>-->
    <div class="container">

            <div class="row">
            <div class="col-md-12">
                
                <div class="box"><div class="title">All Task</div>
                    <div class="body">
                        <ul class="list-group">
                            <li class="list-group-item" style="font-size: 20px;">
                        <!--/////////////////////////////////////////////-->
                        <div class="row">
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
<!--                            <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
                                <input  type="text" />
                                <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                <span></span> <b class="caret"></b>
                            </div>
                                <input type="submit" value="Change Date" />-->
                            </form>
                        </div> 
                        <div class="row">
                                                        <div class="form-group">
                                        <label class="control-label col-sm-3" >Day:</label>
                                        <div class='col-sm-6'>
                                                <div class='input-group date' id='datetimepicker1'>
                                                    <input name="datepk" id="datepk" type='text' value="06/12/2017 10:51 AM" class="form-control" />
                                                    <span class="input-group-addon">
                                                        <span class="glyphicon glyphicon-calendar"></span>
                                                    </span>
                                                </div>
                                            
                                        </div>
                                        <script type="text/javascript">
                                            $('#datetimepicker1').datetimepicker({
                                                daysOfWeekDisabled: [0,2,3,4,5,6]
                                            });
                                        </script>
                                        <div class="col-sm-3"><button id="cdate" class="btn btn-block btn-info">Change Start Date</button></div>
                            </div>
                            <!--<input type="text" name="daterange" id="dateranger" value="2017/01/01 1:30 PM - 2017/01/01 2:00 PM" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%" readonly/>-->
                            
                        </div>
                        <!--////////////////////////////////////////////-->
                        
                            </li>
                            </ul>
                        <div id="dpk"></div>
                    </div>
                </div>    
            </div>
        </div> <!-- row end -->
    </div>
    </body>
</html>
<?php
}
 } else{
	header('Location: index.php');
}?>